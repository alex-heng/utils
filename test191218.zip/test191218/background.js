const url = chrome.runtime.getURL('data.json');
let current = -1;

function registerOnClicked(key) {
    chrome.browserAction.onClicked.addListener(function(tab) {
        if (current === -1) {
            chrome.tabs.executeScript({
                file: 'contentScript.js'
            });

            current++;
        }

        chrome.tabs.sendMessage(tab.id, {index: current});

        chrome.browserAction.setBadgeText({text: Object.keys(key)[current]});
        if (current >= 15) {
            current = 0;
        }
        else {
            current++;
        }
    });
}

fetch(url)
    .then((response) => response.json()) //assuming file contains json
    .then((json) => {
        registerOnClicked(json.key);
    });
    