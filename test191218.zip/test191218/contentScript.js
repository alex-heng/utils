const url = chrome.runtime.getURL('data.json');

let mapJson, currentJson, currentIndex = -1
window.addEventListener('keydown', function(evt) {
    evt.preventDefault()
    const valueToUse = mapJson.map[mapJson.key[Object.keys(mapJson.key)[currentIndex]]][evt.key] || evt.key
    evt.srcElement.value += valueToUse;
    // console.log('keydown', evt.key, evt.srcElement, 
    
});

fetch(url)
    .then((response) => response.json()) //assuming file contains json
    .then((json) => {
        mapJson = json
    });

chrome.runtime.onMessage.addListener(
    function(message, callback) {
        currentIndex = message.index
        console.log(currentIndex, message.index)
        // currentJson = mapJson[Object.keys(mapJson.key)[currentIndex]]
    });